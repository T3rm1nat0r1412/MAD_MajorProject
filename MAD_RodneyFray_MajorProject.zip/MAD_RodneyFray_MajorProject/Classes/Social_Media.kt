package com.example.majorproject_rodneyfray
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class Social_Media : AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.social)

        val webView = findViewById<WebView>(R.id.webView)
        webView.webViewClient = WebViewClient()

        webView.forceLayout()
        val fButton = findViewById<ImageButton>(R.id.facebookbtn)
        val iButton = findViewById<ImageButton>(R.id.igbutton)
        val tButton = findViewById<ImageButton>(R.id.twitterbtn)


        fButton.setOnClickListener(){

            webView.loadUrl("https://www.facebook.com/uccjamaica")
        }
        tButton.setOnClickListener(){
            webView.settings.javaScriptEnabled= true
            webView.loadUrl("https://www.twitter.com/uccjamaica")
        }
        iButton.setOnClickListener(){
            webView.settings.javaScriptEnabled= true
            webView.loadUrl("https://www.instagram.com/uccjamaica")
        }
    }
}
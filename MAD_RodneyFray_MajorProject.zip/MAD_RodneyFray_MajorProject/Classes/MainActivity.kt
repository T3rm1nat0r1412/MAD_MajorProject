package com.example.majorproject_rodneyfray

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.*



class MainActivity : AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var courseBtn = findViewById<ImageButton>(R.id.Coursesbtn)
        var admissionsBtn = findViewById<ImageButton>(R.id.Admissionsbtn)
        var socialBtn = findViewById<ImageButton>(R.id.Socialbtn)
        var facultyBtn = findViewById<ImageButton>(R.id.Facultybtn)
        var coursetxt = findViewById<TextView>(R.id.courseTxt)
        var admissiontxttxt = findViewById<TextView>(R.id.admissiontxt)
        var socialtxt = findViewById<TextView>(R.id.SocialTxt)
        var facultytxt = findViewById<TextView>(R.id.FacultyTxt)
        val FAB = findViewById<FloatingActionButton>(R.id.EmailAB)



        courseBtn.setOnClickListener() {
            startActivity(Intent(this, Courses::class.java))
        }

        admissionsBtn.setOnClickListener() {
            startActivity(Intent(this, Admissions::class.java))
        }


        socialBtn.setOnClickListener() {
            startActivity(Intent(this, Social_Media::class.java))

        }

        facultyBtn.setOnClickListener() {
            startActivity(Intent(this, Faculty::class.java))
        }
        FAB.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "ithod@ucc.edu.jm",null))
            startActivity(Intent.createChooser(emailIntent, "Email HOD..."))
        }
    }
}
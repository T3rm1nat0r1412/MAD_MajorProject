package com.example.majorproject_rodneyfray

data class Data(var Name : String, var Credit : Int, var Desc : String, var Code : String) {

}
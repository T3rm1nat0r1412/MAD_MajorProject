package com.example.majorproject_rodneyfray

import android.annotation.SuppressLint
import android.database.DatabaseUtils
import android.database.sqlite.*


val DATABASE_NAME = "Course"
val Table_Name = "Course_Library"
val COL_Credit = "Credit"
val COL_Name = "Name"
val COL_Desc = "Desc"
val COL_Code = "Code"




class DBHelper(var context: Courses) : SQLiteOpenHelper (context, DATABASE_NAME,null,1) {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = "CREATE TABLE " + Table_Name + "(" +
                COL_Name + " VARCHAR(256) NOT NULL," +
                COL_Credit + " INT NOT NULL," +
                COL_Desc + " VARCHAR(256) NOT NULL," +
                COL_Code + " VARCHAR(256) NOT NULL)";


        db?.execSQL(createTable)

        val insertCourse ="INSERT INTO $Table_Name Values ('Mobile App Development','3','Android Application development Course','ITT420') ,('Internet Authoring II','3','Web Development Tools','ITT307'), ('Database Management Systems ','3','Basic SQL database management' ,'ITT210')," +
                "('Discreet Mathematics II','3','Continued Fundamental calculations for Comp Sci and Mathematics majors','ITT300')," +
                "('Data Structure and File Management','3','Fundamentals of file and how they interact with systems','ITT203')," +
                "('Data Communications & Networks I','3','Networking fundamentals','ITT201')," +
                "('Discreet Mathematics I','3','Fundamental calculations for Comp Sci and Mathematics majors','ITT102')," +
                "('Object Oriented Programming Using C++','3','Exploring the innards of PC and laptop computers and their workings','ITT105'),"+
                "('Computer Troubleshooting and Repairs','3','Fundamentals of OOP using C++','ITT200')," +
                "('Porgramming Techniques','3','Fundamentals of Programming using Python','ITT103')"



        db?.execSQL(insertCourse)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }


    @SuppressLint("Range")
    fun getCourse(ID: Int): String {
        var courseString = ""
        var CreditString = ""
        var NameString = ""
        var DescString = ""
        var CodeString = ""

        val datab = DBHelper(context)
        val da = this.readableDatabase
        val query = da.rawQuery("Select * from $Table_Name where rowid = $ID", null)


        if (query != null) {
            query.moveToNext()

            NameString = query.getString(0)
            CreditString = query.getString(1)
            DescString = query.getString(2)
            CodeString = query.getString(3)
        } else {

        }
        query.close()
        da.close()
        courseString = "Course Name : $NameString   \n" +
                "Description: :$DescString \n" +
                "Credits:  :  $CreditString \n" +
                "Course Code:  $CodeString"
        return courseString
    }

    fun getSize(): Long {
        val db = this.readableDatabase;
        var count = DatabaseUtils.queryNumEntries(db, Table_Name)
        if (count.toString().isNotEmpty())

        else{


        }
        db.close();
        return count;
    }
}









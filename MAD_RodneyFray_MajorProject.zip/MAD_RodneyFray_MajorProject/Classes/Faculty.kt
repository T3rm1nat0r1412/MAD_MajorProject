package com.example.majorproject_rodneyfray
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle
import android.widget.ImageButton

class Faculty : AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lecturer_view)

        var callbtn1 = findViewById<ImageButton>(R.id.callbtn1)
        var callbtn2 = findViewById<ImageButton>(R.id.callbtn2)
        var callbtn3 = findViewById<ImageButton>(R.id.callbtn3)
        var callbtn4 = findViewById<ImageButton>(R.id.callbtn4)
        var callbtn5 = findViewById<ImageButton>(R.id.callbtn5)
        var emailbtn1 = findViewById<ImageButton>(R.id.emailbutton1)
        var emailbtn2 = findViewById<ImageButton>(R.id.emailbutton2)
        var emailbtn3 = findViewById<ImageButton>(R.id.emailbutton3)
        var emailbtn4 = findViewById<ImageButton>(R.id.emailbutton4)
        var emailbtn5 = findViewById<ImageButton>(R.id.emailbutton5)

        callbtn1.setOnClickListener(){
            val callIntent = Intent (Intent.ACTION_CALL,Uri.parse("tel:"+"18768382408"))
            startActivity(callIntent)
        }
        callbtn2.setOnClickListener(){
            val callIntent = Intent (Intent.ACTION_CALL,Uri.parse("tel:"+"18762838582"))
            startActivity(callIntent)
        }
        callbtn3.setOnClickListener(){
            val callIntent = Intent (Intent.ACTION_CALL,Uri.parse("tel:"+"18769063000"))
            startActivity(callIntent)
        }
        callbtn4.setOnClickListener(){
            val callIntent = Intent (Intent.ACTION_CALL,Uri.parse("tel:"+"18762182935"))
            startActivity(callIntent)
        }
        callbtn5.setOnClickListener(){
            val callIntent = Intent (Intent.ACTION_CALL,Uri.parse("tel:"+"18769063000"))
            startActivity(callIntent)
        }
        emailbtn1.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "deanmst@ucc.edu.jm",null))
            startActivity(Intent.createChooser(emailIntent, "Emailing Dean..."))
        }
        emailbtn2.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "hosbourne@ucc.edu.jm ",null))
            startActivity(Intent.createChooser(emailIntent, "Emailing Lecturer Henry Osbourne..."))
        }
        emailbtn3.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "advanhorne@faculty.ucc.edu.jm",null))
            startActivity(Intent.createChooser(emailIntent, "Emailing Lecturer Adrian Vanhorne..."))
        }
        emailbtn4.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "ithod@ucc.edu.jm",null))
            startActivity(Intent.createChooser(emailIntent, "Emailing Acting HOD..."))
        }
        emailbtn5.setOnClickListener(){
            val emailIntent = Intent (Intent.ACTION_SENDTO, Uri.fromParts("mailto", "cwhite01@faculty.ucc.edu.jm",null))
            startActivity(Intent.createChooser(emailIntent, "Emailing Lecturer Cecil White..."))
        }
    }
}
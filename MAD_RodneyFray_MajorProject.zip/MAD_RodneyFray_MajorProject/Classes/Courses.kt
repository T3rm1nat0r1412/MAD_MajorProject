package com.example.majorproject_rodneyfray
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity


class Courses : AppCompatActivity()  {
    private var allCourses: Array<String> = arrayOf("")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.courses)
        val listView = findViewById<ListView>(R.id.listView)

            var rowid: Int = 1
            val datab = DBHelper(this)
            val db = datab.readableDatabase
            var rowSize = datab.getSize()
            allCourses[0] = ""


            for (i in rowid..rowSize.toInt()) {
                var courseList = datab.getCourse(rowid)
                allCourses += courseList
                rowid++
            }
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,allCourses)
            listView.adapter = adapter

        }
}